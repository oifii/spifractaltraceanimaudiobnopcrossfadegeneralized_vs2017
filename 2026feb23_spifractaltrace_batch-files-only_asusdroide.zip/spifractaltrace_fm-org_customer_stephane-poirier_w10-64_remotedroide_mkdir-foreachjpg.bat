@echo off
rem https://stackoverflow.com/questions/138497/iterate-all-files-in-a-directory-using-a-for-loop
rem https://stackoverflow.com/questions/5777400/how-to-use-random-in-batch-script
rem https://stackoverflow.com/questions/7522740/counting-in-a-for-loop-using-windows-batch-script
rem
rem creates an individual folder for each *.jpg file in specified folder
rem each individual folders have the specified folder name suffixed by (seti) with i=1 to n
rem
setlocal enableextensions enabledelayedexpansion

set jpgpath="D:\video\animals"
call :loop1 !jpgpath!
call :loop2 !jpgpath!
exit /b

:loop1
rem echo %~1
SET /a count = 0
for /r %~1 %%f in (*.jpg) do (
	echo "%%f"
	set /a count += 1
)
echo "total num of *.jpg files = %count%"
exit /b


:loop2
rem echo %~1
set jpgpathtag1="(set"
set jpgpathtag2=")"
set twelvekgen0tag="(12000x12000)(gen0)"
set twelvekgen1tag="(12000x12000)(gen1)"
set twelvekgen2tag="(12000x12000)(gen2)"
set count=1
for /r %~1 %%f in (*.jpg) do (
	rem echo !count!
	
	rem removing quotes
	set outputpath=!jpgpath:"=!
	rem echo %outputpath%
	rem removing quotes from jpgpathtag1 and concatenating
	set outputpath=!outputpath!!jpgpathtag1:"=!
	rem concatenating count
	set outputpath=!outputpath!!count!
	rem removing quotes from jpgpathtag2 and concatenating
	set outputpath=!outputpath!!jpgpathtag2:"=!
	rem concatenating gen0
	set outputpathgen0=!outputpath!!twelvekgen0tag:"=!
	rem concatenating gen1
	set outputpathgen1=!outputpath!!twelvekgen1tag:"=!
	rem concatenating gen2
	set outputpathgen2=!outputpath!!twelvekgen2tag:"=!
	rem inserting back one set of quotes
	set outputpath="!outputpath!"
	set outputpathgen0="!outputpathgen0!"
	set outputpathgen1="!outputpathgen1!"
	set outputpathgen2="!outputpathgen2!"

	echo mkdir !outputpath!
	mkdir !outputpath!
	echo copy "%%f" !outputpath!
	copy "%%f" !outputpath!
	echo mkdir !outputpathgen0!
	mkdir !outputpathgen0!
	echo mkdir !outputpathgen1!
	mkdir !outputpathgen1!
	echo mkdir !outputpathgen2!
	mkdir !outputpathgen2!
	set /a count+=1
)
rem goto loop2


endlocal
